using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

using System.Runtime.InteropServices;


namespace fullmecodeviewer
{
    public partial class Form1 : Form
    {
        int SW_SHOWNOACTIVATE = 4;

        [DllImport("user32.dll", EntryPoint = "FindWindow", SetLastError = true)]
        private static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

        [DllImport("user32.dll", EntryPoint = "FindWindowEx", SetLastError = true)]
        private static extern IntPtr FindWindowEx(IntPtr hwndParent, uint hwndChildAfter, string lpszClass, string lpszWindow);

        [DllImport("user32.dll", EntryPoint = "ShowWindow", CharSet = CharSet.Auto)]
        public static extern int ShowWindow(IntPtr hwnd, int nCmdShow);

        [DllImport("user32.dll", EntryPoint = "SendMessage", SetLastError = true, CharSet = CharSet.Auto)]
        private static extern int SendMessage(IntPtr hwnd, uint wMsg, int wParam, int lParam);

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        public static extern int PostMessage(IntPtr hwnd, int msg, IntPtr wparam, IntPtr lparam);

        [DllImport("user32.dll", EntryPoint = "SetForegroundWindow", SetLastError = true)]
        private static extern void SetForegroundWindow(IntPtr hwnd);


     
        public Form1(string imageFilename)
        {
            InitializeComponent();

            Bitmap fullme_CODE_jpg = new Bitmap(imageFilename);
            pictureBox1.Image = (Image)fullme_CODE_jpg;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            //MessageBox.Show("load form1");

            IntPtr hwndFCV = FindWindow(null, "fullme CODE Viewer"); //���� fullme CODE Viewer �ľ��
            //SetForegroundWindow(hwndFCV); //�� fullme CODE Viewer ��Ϊ��ǰ�����
            int isShow = ShowWindow(hwndFCV, SW_SHOWNOACTIVATE);
            
            IntPtr hwndZMUD = FindWindow(null, "zMUD"); //���� zMUD �ľ��
            SetForegroundWindow(hwndZMUD); //�� zMUD ��Ϊ��ǰ�����
            
            //MessageBox.Show(isShow.ToString());
            
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            Application.Exit();
        }

        private void Form1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox1_LoadCompleted(object sender, AsyncCompletedEventArgs e)
        {
            
        }

        private void Form1_Activated(object sender, EventArgs e)
        {

        }

    }
}