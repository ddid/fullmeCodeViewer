﻿using System;
using System.Collections.Generic;
using System.Net;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

using System.Runtime.InteropServices;

namespace fullmecodeviewer
{
    static class Program
    {

        private static string Get_html_text(string from_url)
        {
            // Create a request for the URL.         
            WebRequest request = WebRequest.Create(from_url);

            // If required by the server, set the credentials.
            request.Credentials = CredentialCache.DefaultCredentials;

            // Get the response.
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();

            // Display the status.
            //Console.WriteLine(response.StatusDescription);

            // Get the stream containing content returned by the server.
            Stream dataStream = response.GetResponseStream();

            // Open the stream using a StreamReader for easy access.
            StreamReader reader = new StreamReader(dataStream);

            // Read the content.
            string html_text = reader.ReadToEnd();

            // Display the content.
            //Console.WriteLine(html_text);

            // Cleanup the streams and the response.
            reader.Close();
            dataStream.Close();
            response.Close();

            return html_text;
        }

        private static string Get_jpg_url(string from_html_text)
        {
            string jpg_url = null;

            Regex r = new Regex("/b2evo_captcha_tmp.*jpg");
            Match m = r.Match(from_html_text); // 在字符串中匹配

            if (m.Success)
            {
                jpg_url = m.ToString();
                jpg_url = "http://pkuxkx.net/antirobot" + jpg_url;
                //Console.WriteLine("Found match at position " + m.Index); //输入匹配字符的位置
                //Console.WriteLine(jpg_url);
            }
            else
            {
                jpg_url = null;
                Console.WriteLine("No match!");
            }

            return jpg_url;
        }

        private static void Download_jpg_to_file(string from_jpg_url)
        {
            string outputFile = "fullme_CODE.jpg";

            // Create a request for the URL.         
            WebRequest request = WebRequest.Create(from_jpg_url);

            // If required by the server, set the credentials.
            request.Credentials = CredentialCache.DefaultCredentials;

            // Get the response.
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();

            // Display the status.
            //Console.WriteLine(response.StatusDescription);

            // Get the stream containing content returned by the server.
            Stream inStream = response.GetResponseStream();

            Stream outStream = File.OpenWrite(outputFile);
            byte[] buffer = new byte[4096];
            int size = 0;
            while ((size = inStream.Read(buffer, 0, 4096)) > 0)
            {
                outStream.Write(buffer, 0, size);
            }

            // Cleanup the streams and the response.
            //reader.Close();
            inStream.Close();
            response.Close();
            outStream.Close();
        }

   
        [DllImport("user32.dll", EntryPoint = "FindWindow", SetLastError = true)]
        private static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

        [DllImport("user32.dll", EntryPoint = "FindWindowEx", SetLastError = true)]
        private static extern IntPtr FindWindowEx(IntPtr hwndParent, uint hwndChildAfter, string lpszClass, string lpszWindow);

        [DllImport("user32.dll", EntryPoint = "ShowWindow", CharSet = CharSet.Auto)]
        public static extern int ShowWindow(IntPtr hwnd, int nCmdShow);

        [DllImport("user32.dll", EntryPoint = "SendMessage", SetLastError = true, CharSet = CharSet.Auto)]
        private static extern int SendMessage(IntPtr hwnd, uint wMsg, int wParam, int lParam);

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        public static extern int PostMessage(IntPtr hwnd, int msg, IntPtr wparam, IntPtr lparam);

        [DllImport("user32.dll", EntryPoint = "SetForegroundWindow", SetLastError = true)]
        private static extern void SetForegroundWindow(IntPtr hwnd);
      
        
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {               
            string imageFileName = "fullme_CODE.jpg";
            string antirobot_url = null;
            int SW_SHOW = 5;
            const int WM_CLOSE = 0x0010;
            //const int KEY_Y = 0x0090;

            if (args.Length == 1)
            {
                if (args[0] == "-close")
                {
                    IntPtr hwndFCV = FindWindow(null, "fullme CODE Viewer"); //查找 fullme CODE Viewer 的句柄
                    SetForegroundWindow(hwndFCV); //将 fullme CODE Viewer 设为当前活动窗口
                    PostMessage(hwndFCV, WM_CLOSE, IntPtr.Zero, IntPtr.Zero); //发送关闭命令给当前的fullme CODE Viewer窗口

                    return;
                }
                else
                {
                    antirobot_url = args[0];
                    //MessageBox.Show(antirobot_url);
                }
            }
            
            if (antirobot_url == null || antirobot_url == "")
            {
                MessageBox.Show("不能获得访问地址！");
                return;
            }

            string html = Get_html_text(antirobot_url);
            //MessageBox.Show(html);
            string jpg_url = Get_jpg_url(html);
            //MessageBox.Show(jpg_url);

            if (html == null || jpg_url == null)
            {
                MessageBox.Show("不能获得页面/文件！");
                return;
            }

            Download_jpg_to_file(jpg_url);
            
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1(imageFileName));

        }
    }
}